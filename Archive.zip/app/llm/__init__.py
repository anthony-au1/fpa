"""Provider-independent model boundary."""
