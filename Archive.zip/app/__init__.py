"""Financial processing agent foundation."""
