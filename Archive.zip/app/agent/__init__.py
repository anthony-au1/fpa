"""Explicit, bounded workflow graph."""
