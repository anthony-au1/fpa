"""FastAPI boundary."""
