"""SQLite persistence boundary."""
