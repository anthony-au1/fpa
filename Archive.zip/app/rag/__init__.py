"""Untrusted-document retrieval boundary."""
